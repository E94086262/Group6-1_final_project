from button import Button
from all_image import *
from menu.main_menu import Menu
from level_1.game import Level_one
from level_2.game import Level_two


class Change_page:
    """
    Used in start_menu.py to control the current menu or enter a level.
    """
    def __init__(self):
        self.level_state = [1, 0, 0, 0, 0]
        self.lv1 = Level_one()
        self.lv2 = Level_two()

    def choose_menu(self, response):
        if response == 'main menu':
            menu = Menu.MainMenu()
        elif response == 'level menu':
            menu = Menu.LevelMenu(self.level_state)
        elif response == 'introduction':
            menu = Menu.Introduction()
        else: # 防故障用(之後再移除)
            menu = Menu.MainMenu()

        menu.draw()
        quit_game, menu_response = menu.update()
        return quit_game, menu_response

    def choose_level(self, response):
        if response == 'LV1':
            game = self.lv1
        elif response == 'LV2':
            game = self.lv2
        else:  # 防故障用(之後再移除)
            game = Menu.LevelMenu(self.level_state)

        game.draw()
        quit_game, level_response = game.update()
        return quit_game, level_response

    def update_level_state(self):
        self.level_state = [1, self.lv1.unlock, self.lv2.unlock, 0, 0]

