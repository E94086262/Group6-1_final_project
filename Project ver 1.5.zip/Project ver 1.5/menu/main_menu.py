import pygame
import os
from settings import WIN_WIDTH, WIN_HEIGHT
from button import Button
from all_image import *
from level_1.game import Level_one
from level_2.game import Level_two


class Menu:
    """
    Construct the menu for the start of the level_2.
    """
    def __init__(self, button_list, response):
        self.win = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
        self.bg_image = MENU_BACKGROUND
        self.__buttons = button_list
        self.button_response = response

    def draw(self):
        """
        Draw everything here.
        :return: None
        """
        # draw background
        self.win.blit(self.bg_image, (0, 0))
        self.win.blit(LOGO_IMAGE_small, (1017, 2))
        # draw button
        for but in self.__buttons:
            self.win.blit(but.image, but.rect)
        pygame.display.update()

    def update(self):
        """
        Update for quit event and click button.
        :return game_quit: whether quit the level_2.
                self.button_response: used for changing to next page.
        """
        game_quit = False
        # event loop
        mouse_x, mouse_y = pygame.mouse.get_pos()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_quit = True
                return game_quit, self.button_response
            # player click action
            if event.type == pygame.MOUSEBUTTONDOWN:
                for btn in self.__buttons:
                    if btn.clicked(mouse_x, mouse_y):
                        return game_quit, btn.response()

        return game_quit, self.button_response

    # 用繼承寫出三個主要頁面
    @classmethod
    def MainMenu(cls):  # 主頁面
        btn_list = [Button(LEVEL_BTN_IMAGE, "level menu", 400, 200),
                    Button(INTRO_BTN_IMAGE, "introduction", 800, 200),]
        main_menu = cls(btn_list, 'main menu')
        return main_menu

    @classmethod
    def Introduction(cls):  # 角色介紹頁面
        btn_list = [Button(RETURN_IMAGE, "main menu", 75, 50),
                    Button(WAIT_IMAGE, "wait", 600, 230)]
        introduction = cls(btn_list, 'introduction')
        return introduction

    @classmethod
    def LevelMenu(cls, level_state):  # 關卡選擇頁面
        btn_list = [Button(RETURN_IMAGE, "main menu", 75, 50)]
        Level_unlock = [Button(LV1_OP_BTN_IMAGE, "LV1", 200, 220),
                        Button(LV2_OP_BTN_IMAGE, "LV2", 400, 220),
                        Button(LV3_OP_BTN_IMAGE, "LV3", 600, 220),
                        Button(LV4_OP_BTN_IMAGE, "LV4", 800, 220),
                        Button(LV5_OP_BTN_IMAGE, "LV5", 1000, 220)]

        Level_locked = ["Level 1 has no locked problem.",
                        Button(LV2_CL_BTN_IMAGE, "LV", 400, 220),
                        Button(LV3_CL_BTN_IMAGE, "LV", 600, 220),
                        Button(LV4_CL_BTN_IMAGE, "LV", 800, 220),
                        Button(LV5_CL_BTN_IMAGE, "LV", 1000, 220)]

        # 如果關卡解鎖就放上解鎖圖按鈕
        btn_list.extend([Level_unlock[i] if level_state[i] else Level_locked[i] for i in range(5)])

        level_menu = cls(btn_list, 'level menu')
        return level_menu
