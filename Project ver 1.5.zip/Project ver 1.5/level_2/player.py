import pygame
import os
from color_settings import *
from level_2.player_button_menu import Send_troops_menu
from level_2.tower import Tower
from level_2.cat import Cats
from level_2.mana import Mana
from level_2.ending_page import Ending_page
from all_image import *

pygame.init()


class PlayerGroup:
    def __init__(self):
        self.__reserved_members = []
        self.__expedition = []
        self.button_response = None
        self.send_troops_menu = Send_troops_menu()
        self.tower = Tower.Player_tower()
        self.cd_count = 0  # used in self.is_cool_down()
        self.cd_max_count = 60  # used in self.is_cool_down()
        self.mana = Mana()
        self.hp_count = False

    def get_click(self, x, y):
        """
        Return Whether the button is clicked
        :return: bool
        """
        for btn in self.send_troops_menu.get_buttons():
            if btn.clicked(x, y):
                self.button_response = btn.response()

    def update(self, enemy_group, win):
        summon_cat = None  # reset summon response
        if self.button_response == "normal":
            summon_cat = Cats.Normal_Cat()
        elif self.button_response == "mask":
            summon_cat = Cats.Mask_Cat()
        elif self.button_response == "sanitizer":
            summon_cat = Cats.Sanitizer_Cat()
        if self.mana.summon(summon_cat):
            self.campaign(summon_cat)
        self.mana.update()
        self.button_response = None  # clear button response

        self.attack(enemy_group)
        for cat in self.__expedition:
            if cat.check_moving(enemy_group):  # Control the moving
                cat.move()
            if cat.health <= 0:
                self.retreat(cat)

        if self.tower.health < 0:
            self.tower.health = 0
        elif self.tower.health == 0:
            if self.hp_count is not True:
                self.hp_count = True
            else:
                return True

        return False

    def ending(self):
        return Ending_page.Loss()

    def draw(self, win):
        # draw player tower
        self.tower.draw(win)

        for cat in self.__expedition:
            win.blit(cat.image, cat.rect)
            # draw health bar
            bar_width = cat.rect.w * (cat.health / cat.max_health)
            max_bar_width = cat.rect.w
            bar_height = 5
            pygame.draw.rect(win, RED, [cat.rect.x, cat.rect.y - 10, max_bar_width, bar_height])
            pygame.draw.rect(win, GREEN, [cat.rect.x, cat.rect.y - 10, bar_width, bar_height])

        # draw button menu
        self.send_troops_menu.draw(win)

        # draw mana value
        self.mana.draw(win)
        pygame.display.update()

    def campaign(self, cat_type):
        """
        Enemy go on an expedition.
        """
        self.__expedition.append(cat_type)

    def get(self):
        """
        Get the enemy list
        """
        return self.__expedition

    def is_empty(self):
        """
        Check the enemy list is empty
        """
        return True if (self.__expedition == []) else False

    def retreat(self, cat):
        """
        Remove the enemy from the expedition
        :param cat: class Cats()
        :return: None
        """
        self.__expedition.remove(cat)

    def attack(self, enemy_group):
        """
        Attack the enemy in range if it cool down
        :param enemy_group: EnemyGroup()
        :return: None
        """
        for cat in self.__expedition:
            cat.attack(enemy_group)






