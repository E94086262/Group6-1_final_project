import pygame
import random
from color_settings import *
from level_2.player_button_menu import Send_troops_menu
from level_2.tower import Tower
from level_2.virus import Virus
from level_2.ending_page import Ending_page

pygame.init()


class EnemyGroup:
    def __init__(self):
        self.__reserved_members = [Virus.Normal_Virus() for _ in range(100)]
        self.__expedition = []
        self.button_response = None
        self.send_troops_menu = Send_troops_menu()
        self.tower = Tower.Enemy_tower()
        self.hp_count = False
        self.cd_count = 0
        self.cd_max_count = 80
        self.campaign_count = 125
        self.campaign_max_count = 120   # (unit: frame)

    def update(self, player_group, win):
        self.campaign()
        self.attack(player_group)
        for virus in self.__expedition:
            # Control the move
            if virus.check_moving(player_group):
                virus.move()
            if virus.health <= 0:
                self.retreat(virus)

        if self.tower.health < 0:
            self.tower.health = 0
        elif self.tower.health == 0:
            if self.hp_count is not True:
                self.hp_count = True
            else:
                return True

        return False

    def ending(self):
        return Ending_page.Win()

    def draw(self, win):
        # draw tower
        self.tower.draw(win)

        for virus in self.__expedition:
            win.blit(virus.image, virus.rect)
            # draw health bar
            bar_width = virus.rect.w * (virus.health / virus.max_health)
            max_bar_width = virus.rect.w
            bar_height = 5
            pygame.draw.rect(win, RED, [virus.rect.x, virus.rect.y - 10, max_bar_width, bar_height])
            pygame.draw.rect(win, GREEN, [virus.rect.x, virus.rect.y - 10, bar_width, bar_height])

    def campaign(self):
        """
        Enemy go on an expedition.
        """
        if self.campaign_count > self.campaign_max_count and self.__reserved_members:
            self.__expedition.append(self.__reserved_members.pop())
            self.campaign_count = 0
            self.campaign_max_count = random.choice([80, 100, 120, 140])  # 隨機派兵速度
        else:
            self.campaign_count += 1

    def get(self):
        """
        To return the enemy list.
        """
        return self.__expedition

    def is_empty(self):
        """
        Check the enemy list is empty
        """
        return True if (self.__expedition == []) else False

    def retreat(self, cat):
        """
        Remove the enemy from the expedition
        :param cat: class Cats()
        :return: None
        """
        self.__expedition.remove(cat)

    def attack(self, player_group):
        """
        Attack the cat in range if it cool down
        :param player_group: PlayerGroup()
        :return: None
        """
        for virus in self.__expedition:
            virus.attack(player_group)
