import pygame
import os
from level_2.enemy import EnemyGroup
from level_2.player import PlayerGroup
from settings import WIN_WIDTH, WIN_HEIGHT, FPS
from all_image import *


class Level_two:
    def __init__(self):
        self.win = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
        self.bg_image = BACKGROUND_IMAGE
        self.enemies = EnemyGroup()
        self.player = PlayerGroup()
        self.gameover = False
        self.unlock = False

    def draw(self):
        """
        Draw everything in this method.
        :return: None
        """
        # draw background
        self.win.blit(self.bg_image, (0, 0))
        self.win.blit(LOGO_IMAGE_small, (1017, 2))
        # draw enemies
        self.enemies.draw(self.win)
        # draw cats
        self.player.draw(self.win)

        if self.gameover is True:
            self.enemies = EnemyGroup()
            self.player = PlayerGroup()
            self.gameover = False

        pygame.display.update()

    def update(self):
        game_quit = False
        # event loop
        mouse_x, mouse_y = pygame.mouse.get_pos()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_quit = True
                return game_quit, ''
            # player click action
            if event.type == pygame.MOUSEBUTTONDOWN:
                self.player.get_click(mouse_x, mouse_y)

        # update player action
        game_over_loss = self.player.update(self.enemies, self.win)
        # update enemy action
        game_over_win = self.enemies.update(self.player, self.win)

        if game_over_loss or game_over_win:
            return self.game_over(game_over_loss, game_over_win)

        return game_quit, 'LV2'

    def game_over(self, losing, winning):
        self.gameover = True
        if losing:
            consequence = self.player.ending()
        elif winning:
            consequence = self.enemies.ending()
            self.unlock = True  # 過關解鎖下一關
        consequence.draw(self.win)
        jump_page = False
        while jump_page is not True:
            game_quit, response, jump_page = consequence.update()
        return game_quit, response

