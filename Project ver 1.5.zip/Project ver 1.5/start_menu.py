import pygame
from menu.intro import Intro
from menu.change_page import Change_page
from settings import WIN_WIDTH, WIN_HEIGHT, FPS

pygame.init()
pygame.mixer.init()


class StartMenu:
    def __init__(self):
        # win
        self.menu_win = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
        # set start page as intro
        self.page = 'intro'

    def menu_run(self):
        quit_game = False
        clock = pygame.time.Clock()
        pygame.display.set_caption("Cat-to-vid")
        intro = Intro()
        change_page = Change_page()

        while not quit_game:
            clock.tick(FPS)
            if self.page == 'intro':  # 開場動畫 (強制看完 LOGO，不准關XD)
                self.page = intro.fade_effect()
            elif self.page.startswith('LV'):
                quit_game, self.page = change_page.choose_level(self.page)  # 關卡選擇
            else:
                quit_game, self.page = change_page.choose_menu(self.page)  # 主頁面選單

            change_page.update_level_state()  # 更新關卡解鎖狀態

        pygame.quit()

