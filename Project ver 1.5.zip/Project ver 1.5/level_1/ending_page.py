from button import Button
from all_image import *


class Ending_page:
    """
    Construct the menu for the ending of the level_2.
    """
    def __init__(self, image, button_list):
        self.image = image
        self.__buttons = button_list

    def draw(self, win):
        """
        Draw buttons on a transparent surface.
        :return: None
        """
        # 透明白底 QAQ
        surface = pygame.Surface((WIN_WIDTH, WIN_HEIGHT), pygame.SRCALPHA)
        pygame.draw.rect(surface, (255, 255, 255, 170), [0, 0, WIN_WIDTH, WIN_HEIGHT], 0)
        surface.blit(self.image, (200, 120))
        for but in self.__buttons:
            surface.blit(but.image, but.rect)
        win.blit(surface, (0, 0))
        pygame.display.update()

    def update(self):
        """
        Update for quit event and click button.
        :return game_quit: whether quit the level_2.
                self.button_response: used for changing to next page.
        """
        game_quit = False
        # event loop
        mouse_x, mouse_y = pygame.mouse.get_pos()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_quit = True
                return game_quit, '', True

            # player click action
            if event.type == pygame.MOUSEBUTTONDOWN:
                for btn in self.__buttons:
                    if btn.clicked(mouse_x, mouse_y):
                        return game_quit, btn.response(), True

        return game_quit, "LV1", False

    @classmethod
    def Win(cls):  # 主頁面
        btn_list = [Button(BACK_BTN, "main menu", 350, 550),
                    Button(NEXT_BTN, "LV2", 850, 550)]
        winning = cls(WIN_IMAGE, btn_list)
        return winning

    @classmethod
    def Loss(cls):  # 主頁面
        btn_list = [Button(BACK_BTN, "main menu", 600, 550)]
        loss = cls(LOSE_IMAGE, btn_list)
        return loss
