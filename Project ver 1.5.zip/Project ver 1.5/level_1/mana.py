import pygame
from settings import MANA_X, MANA_Y, MANA_W
from color_settings import *


class Mana:
    def __init__(self):
        self.max_mana = 40
        self.mana = self.max_mana
        self.cd_count = 0
        self.cd_max_count = 20

    def update(self):
        # Restore mana with cd
        if self.cd_count >= self.cd_max_count:
            if self.mana < self.max_mana:
                self.mana += 1
                self.cd_count = 0
        else:
            self.cd_count += 1

    def draw(self, win):
        max_bar_width = MANA_W
        bar_width = max_bar_width * (self.mana / self.max_mana)
        bar_height = 20
        pygame.draw.rect(win, GRAY, [MANA_X, MANA_Y, max_bar_width, bar_height])
        pygame.draw.rect(win, GRAY, pygame.Rect(MANA_X-5, MANA_Y-5, max_bar_width+10, bar_height+10), 2)
        pygame.draw.rect(win, WHITE, [MANA_X, MANA_Y, bar_width, bar_height])  # remaining mana

    def summon(self, cat):
        # 消耗魔力值
        if cat is not None:
            if self.mana >= cat.cost:
                self.mana -= cat.cost
                return True
        return False

