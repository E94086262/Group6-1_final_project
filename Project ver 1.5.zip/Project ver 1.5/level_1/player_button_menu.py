import pygame
import os
from all_image import *


class Send_troops_menu:
    """
    Set on the button of the level_2 screen. Let player choose the cat to fight virus.
     (Used in class PlayerGroup)
    """
    def __init__(self):
        # Add buttons
        self.__buttons = [Button(NORMAL_CAT_BUTTON, "normal", 475, 600),
                          Button(MASK_CAT_BUTTON, "mask", 725, 600)]

    def draw(self, win):
        """
        Draw buttons.
        :return: None
        """
        # draw button
        for but in self.__buttons:
            win.blit(but.image, but.rect)

    def get_buttons(self):
        """
        Return the button list.
        :return: list
        """
        return self.__buttons


class Button:
    def __init__(self, image, name, x, y):
        self.name = name    # name of the button
        self.image = image  # image of the button
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)  # center of the menu image

    def clicked(self, x, y):
        """
        Return Whether the button is clicked
        (This method is call in get_click() method in class TowerGroup)
        :return: bool
        """
        return True if self.rect.collidepoint(x, y) else False

    def response(self):
        """
        Return the button name.
        (This method is call in get_click() method in class TowerGroup)
        :return: str
        """
        return self.name






